﻿using svarog;

namespace svarog.Plugins
{
    // uncomment this to make the plugin register:
    // [Plugin]
    public class MyPlugin : Plugin
    {
        // there are methods here to override :)
    }
}
